package ro.sapientia2015.story.exception;

/**
 * @author Kiss Tibor
 */
public class NotFoundException extends Exception {

    public NotFoundException(String message) {
        super(message);
    }

}
