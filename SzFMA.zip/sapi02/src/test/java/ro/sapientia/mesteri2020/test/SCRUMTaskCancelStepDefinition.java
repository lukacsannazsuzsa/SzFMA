package ro.sapientia.mesteri2020.test;

import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SCRUMTaskCancelStepDefinition {

	protected WebDriver driver;

	@Before
	public void setup() {
		driver = new FirefoxDriver();
	}
	private int childrenSize;
	@Given("^It isn't an element in the task list$")
	public void I_list_the_tasks() throws Throwable {
	    // Express the Regexp above with the code you wish you had
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("http://localhost:8080/");
		
		WebElement listTaskButton = driver.findElement(By.id("list-task-button"));
		listTaskButton.click();
		
		WebElement firstItem = driver.findElement(By.id("task-list"));
		//List<WebElement>children=firstItem.findElements(By.className("well"));
		
		
		Assert.assertTrue("task found",firstItem.getText().equals("No task found."));
		childrenSize = 0;
			
		WebElement addTaskButton = driver.findElement(By.id("add-task-button"));
		addTaskButton.click();
		
	}
	

	@When("^I push the addTask button and enter the \"([^\"]*)\" and cancel$")
	public void I_enter_in_the_title_textbox_and_I_push_the_cancel_button(String additionTerms ) throws Throwable {
		
		WebElement titleTextBox = driver.findElement(By.id("task-title"));
		titleTextBox.clear();
		titleTextBox.sendKeys(additionTerms);
		
		WebElement titleTextBox1 = driver.findElement(By.id("task-description"));
		titleTextBox1.clear();
		titleTextBox1.sendKeys(additionTerms+"_description");

		// Click on addButton
        
		WebElement cancelButton = driver.findElement(By.id("cancel"));
		cancelButton.click();
		// Express the Regexp above with the code you wish you had

	
	}
	
	@Then("^the \"([^\"]*)\" should not appears in the list$")
	public void I_should_get_result_in_new_stories_list(String additionTerms) throws Throwable {
		
		WebElement listTaskButton = driver.findElement(By.id("list-task-button"));
		listTaskButton.click();
		
		WebElement firstItem = driver.findElement(By.id("task-list"));
		//List<WebElement>children=firstItem.findElements(By.className("well"));
		
		
		Assert.assertTrue("task found",firstItem.getText().equals("No task found."));
		}
	
	@After
	public void closeBrowser() {
		driver.quit();
	}

}
