package ro.sapientia.mesteri2019.test;

import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class SCRUMTaskUpdateStepDefinition {

	protected WebDriver driver;

	@Before
	public void setup() {
		driver = new FirefoxDriver();
	}
	private int childrenSize;
	@Given("^It is an element in the task list$")
	public void I_list_the_tasks() throws Throwable {
	    // Express the Regexp above with the code you wish you had
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("http://localhost:8080/");
		
		WebElement listTaskButton = driver.findElement(By.id("list-task-button"));
		listTaskButton.click();
		
		WebElement firstItem = driver.findElement(By.id("task-list"));
		//List<WebElement>children=firstItem.findElements(By.className("well"));
		
		
		Assert.assertFalse("No task found",firstItem.getText().equals("No task found."));
		childrenSize = 0;
			
		WebElement addTaskButton = driver.findElement(By.id("list-task-button"));
		addTaskButton.click();
		
	}
	

	@When("^I push the addTask button and enter the \"([^\"]*)\" and update$")
	public void I_enter_in_the_title_textbox_and_I_push_the_add_button(String updateTitle ) throws Throwable {
		
		
		List<WebElement>children=driver.findElements(By.className("well"));
		
		assertTrue("No task found",children.size()>0);
		childrenSize = children.size();
		children.get(0).findElement(By.tagName("a")).click();
		
		WebElement updateButton = driver.findElement(By.id("update-task-link"));
		updateButton.click();
		//driver.wait(1000);
		WebElement titleField = driver.findElement(By.id("task-title"));
		titleField.sendKeys(Keys.CONTROL + "a");
		titleField.sendKeys(Keys.DELETE);
		titleField.sendKeys(updateTitle);
		
		WebElement updateStoryButton = driver.findElement(By.id("update-task-button"));
		updateStoryButton.click();
	
		
	}
	
	@Then("^the \"([^\"]*)\" should appears in the list$")
	public void I_should_get_result_in_new_stories_list(String additionTerms) throws Throwable {
		
		
		
		WebElement firstItem = driver.findElement(By.className("nav"));
		firstItem.click();
		
		WebElement listTaskButton = driver.findElement(By.id("list-task-button"));
		listTaskButton.click();
		
		WebElement firstItem1 = driver.findElement(By.id("task-list"));
		List<WebElement>children=firstItem1.findElements(By.className("well"));
		
		
		Assert.assertTrue("nem az az elem van az adtbazisban",children.get(0).getText().equals(additionTerms));
		//assertTrue("No elemnt in the list",children.size()+1==childrenSize);
		}
	
	@After
	public void closeBrowser() {
	/*	WebElement firstItem = driver.findElement(By.id("task-list"));
		List<WebElement>children=firstItem.findElements(By.className("well"));
		
		assertTrue("No task found",children.size()>0);
		childrenSize = children.size();
		children.get(0).findElement(By.tagName("a")).click();
		
		WebElement deleteTaskButton = driver.findElement(By.id("delete-task-link"));
		deleteTaskButton.click();
		
		WebElement deleteTaskOk = driver.findElement(By.id("delete-task-button"));
		deleteTaskOk.click();*/
		driver.quit();
	}

}
